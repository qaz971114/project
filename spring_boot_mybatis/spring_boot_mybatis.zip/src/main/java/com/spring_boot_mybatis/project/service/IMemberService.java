package com.spring_boot_mybatis.project.service;

import java.util.HashMap;

public interface IMemberService {
	public String loginCheck(HashMap<String, Object> map);
}
